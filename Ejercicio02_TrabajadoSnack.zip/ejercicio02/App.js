import React, { useState, useEffect } from 'react';
import { Text, StyleSheet, View, FlatList, TouchableHighlight, TouchableWithoutFeedback,
Keyboard, Platform } from 'react-native';
import Agenda from './src/components/agenda';
import Formulario from './src/components/formulario';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Colors from './src/utils/colors';
const App = () => {
// definir el state de contactos
const [contactos, setContactos] = useState([]);
const [mostrarform, guardarMostrarForm] = useState(false);
useEffect(() => {
const obtenerContactosStorage = async () => {
try {
const contactosStorage = await AsyncStorage.getItem('contactos');
if(contactosStorage) {
setContactos(JSON.parse(contactosStorage))
}
} catch (error) {
console.log(error);
}
}
obtenerContactosStorage();
}, []);
// Elimina el contacto del state
const eliminarContacto = id => {
const contactosFiltradas = contactos.filter( contacto => contacto.id !== id );
setContacto( contactoFiltradas );
guardarContactosStorage(JSON.stringify(contactosFiltradas));
}
// Muestra u oculta el Formulario
const mostrarFormulario = () => {
guardarMostrarForm(!mostrarform);
}
// Ocultar el teclado
const cerrarTeclado = () => {
Keyboard.dismiss();
}
// Almacenar los contactos en storage
const guardarContactosStorage = async (contactosJSON) => {
try {
await AsyncStorage.setItem('contactos', contactosJSON);
} catch (error) {
console.log(error);
}
}
return (
<TouchableWithoutFeedback onPress={() => cerrarTeclado() }>
<View style={styles.contenedor}>
<Text style={styles.titulo}>Agenda de Contactos</Text>
<View>
<TouchableHighlight onPress={ () => mostrarFormulario() }
style={styles.btnMostrarForm}>
<Text style={styles.textoMostrarForm}> {mostrarform ? 'Cancelar Agregar Contacto' : 'Crear Nuevo Contacto'} </Text>
</TouchableHighlight>
</View>
<View style={styles.contenido}>
{ mostrarform ? (
<>
<Text style={styles.titulo}>Crear Nuevo Contacto</Text>
<Formulario
contactos={contactos}
setContactos={setContactos}
guardarMostrarForm={guardarMostrarForm}
guardarContactosStorage={guardarContactosStorage}
/>
</>
) : (
<>
<Text style={styles.titulo}> {contactos.length > 0 ? 'Administra tus contactos' :
'No hay contactos, agrega uno'} </Text>
<FlatList
style={styles.listado}
data={contactos}
renderItem={ ({item}) => <Agenda item={item}
eliminarContacto={eliminarContacto} /> }
keyExtractor={ contacto => contacto.id}
/>
</>
) }
</View>
</View>
</TouchableWithoutFeedback>
);
};
const styles = StyleSheet.create({
contenedor: {
backgroundColor: Colors.PRIMARY_COLOR,
flex: 1
},
titulo: {
color: '#FFF',
marginTop: Platform.OS === 'ios' ? 40 : 20 ,
marginBottom: 20,
fontSize: 24,
fontWeight: 'bold',
textAlign: 'center'
},
contenido: {
flex: 1,
marginHorizontal: '2.5%',
},
listado: {
flex: 1,
},
btnMostrarForm: {
padding: 10,
backgroundColor:Colors.BUTTON_COLOR,
marginVertical: 10
},
textoMostrarForm: {
color: '#FFF',
fontWeight: 'bold',
textAlign: 'center'
}
});
export default App;