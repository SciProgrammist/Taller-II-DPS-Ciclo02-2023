import React, { useState } from 'react';
import { Text, StyleSheet, View, TextInput, Button, TouchableHighlight, Alert, ScrollView
} from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import shortid from "react-id-generator";
import colors from '../utils/colors';
const Formulario = ({contactos, setContactos, guardarMostrarForm, guardarContactosStorage}) => {
//variables para el formulario
const [contactoNombre, guardarNombreContacto] = useState('');
const [telefono, guardarTelefono] = useState('');


// Crear nuevo Contacto
const crearNuevoContacto = () => {
// Validar
if(contactoNombre.trim() === '' ||
telefono.trim() === '')
{
// Falla la validación
mostrarAlerta();
return;
}
// Crear una nuevo Contacto
const contacto = { contactoNombre, telefono };
contacto.id = shortid();

// Agregar al state
const contactosNuevo = [...contactos, contacto];
setContactos(contactosNuevo);

// Pasar las nuevas contacos a storage
guardarContactosStorage(JSON.stringify(contactosNuevo));

// Ocultar el formulario
guardarMostrarForm(false);

// Resetear el formulario
guardarNombreContacto('');
guardarTelefono('');

}
// Muestra la alerta si falla la validación
const mostrarAlerta = () => {
Alert.alert(
'Error', // Titulo
'Todos los campos son obligatorios para agregar a un contacto.', // mensaje
[{
text: 'OK' // Arreglo de botones
}]
)
}
return (
<>
<ScrollView style={styles.formulario}>
<View>
<Text style={styles.label}>nombre de Contacto:</Text>
<TextInput
style={styles.input}
onChangeText={ texto => guardarNombreContacto(texto) }
/>
</View>
<View>
<Text style={styles.label}>Teléfono Contacto:</Text>
<TextInput
style={styles.input}
onChangeText={ texto => guardarTelefono(texto) }
keyboardType='numeric'
/>
</View>
<View>
<TouchableHighlight onPress={ () => crearNuevoContacto() }
style={styles.btnSubmit}>
<Text style={styles.textoSubmit}>Crear Nuevo Contacto</Text>
</TouchableHighlight>
</View>
</ScrollView>
</>
);
}
const styles = StyleSheet.create({
formulario: {
backgroundColor: '#FFF',
paddingHorizontal: 20,
paddingVertical: 10,
flex: 1
},
label: {
  fontWeight: 'bold',
fontSize: 18,
marginTop: 20
},
input: {
marginTop: 10,
height: 50,
borderColor: '#e1e1e1',
borderWidth: 1,
borderStyle: 'solid'
},
btnSubmit: {
padding: 10,
backgroundColor:colors.BUTTON_COLOR,
marginVertical: 10
},
textoSubmit: {
color: '#FFF',
fontWeight: 'bold',
textAlign: 'center'
}
})
export default Formulario;