export default{
PRIMARY_COLOR: '#661003',
BUTTON_COLOR: '#036651',
}