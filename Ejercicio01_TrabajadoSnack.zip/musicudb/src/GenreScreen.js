
import React, { useState } from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity } from 'react-native';
import styles from './styles.css'; 

const genres = [
  {
    name: 'Rock',
    albums: [
 {
        title: 'Trench',
        artist: 'Twenty one pilot',
        image: require('./images/albumtrench.jpg'),
        songs: [
          { title: 'Chlorine', duration: '5:54' },
          { title: 'Jumpsuit', duration: '3:58' },
          { title: 'Levitate', duration: '2:25' },
          { title: 'Morph', duration: '4:19' },
          { title: 'My Blood', duration: '3:49' },
          { title: 'Smithereens', duration: '2:57' },
          { title: 'Neon Gravestones', duration: '4:00' },
          { title: 'The Hype', duration: '4:25' },
          { title: 'Nico and the Niners', duration: '3:45' },
          { title: 'Cut My Lip', duration: '4:43' },
          
        ]
      },


      {
        title: 'Infestissuman',
        artist: 'Ghost bc',
        image: require('./images/album1rock'),
        songs: [
          { title: 'Monstrance Clock', duration: '5:53' },
          { title: 'infestissuman', duration: '1:42' },
           { title: 'Per Aspera ad Inferi', duration: '4:09' },
           { title: 'Secular Haze', duration: '5:11' },
           { title: 'Jigolo Har Megiddo', duration: '3:58' },
           { title: 'Ghuleh / Zombie Queen', duration: '7:29' },
           { title: 'Year Zero', duration: '5:50' },
           { title: 'Body and Blood', duration: '3:43' },
           { title: 'Idolatrine', duration: '4:23' },
           { title: 'Depth of Satans Eyes', duration: '5:25' },
        ]
      },
      {
        title: 'Follow the Leader',
        artist: 'Korn',
        image: require('./images/albumkorn'),
        songs: [
            { title: 'Freak on a Leash', duration: '4:15' },
           { title: 'It s On!', duration: '4:28' },
          { title: 'Got the Life', duration: '3:45' },
          { title: 'Dead Bodies Everywhere', duration: '4:44' },
          { title: 'Children of the Korn', duration: '3:52' },
          { title: 'B.B.K.', duration: '3:56' },
          { title: 'Pretty', duration: '4:12' },
          { title: 'All in the Family', duration: '4:48' },
          { title: 'Reclaim My Place', duration: '4:32' },
          { title: 'Seed', duration: '5:54' },
        ]
      },

 {
        title: 'Vol.3:(Subliminal verses)',
        artist: 'Slipknot',
        image: require('./images/album2rock'),
        songs: [
          { title: 'Before I Forget', duration: '4:38' },
          { title: 'Pulse of the Maggots', duration: '4:19' },
          { title: 'Duality', duration: '4:12' },
          { title: 'Scream', duration: '4:31' },
          { title: 'The Blister Exists', duration: '5:19' },
          { title: 'Vermilion', duration: '5:16' },
          { title: 'Vermilion Pt. 2', duration: '3:44' },
          { title: 'The Nameless', duration: '4:28' },
          { title: 'The Virus of Life', duration: '5:25' },
          { title: 'Prelude 3.0', duration: '3:57' },
        ]
      },

       {
        title: 'Use Your Illusion I',
        artist: ' Guns N Roses',
        image: require('./images/album4rock'),
        songs: [
          { id:'1', title: 'November Rain', duration: '8:56' },
          { title: 'Right Next Door to Hell', duration: '3:02' },
          { title: 'Dust N Bones', duration: '4:58' },
          { title: 'Dont Cry', duration: '4:44' },
          { title: 'Perfect Crime', duration: '2:23' },
          { title: 'You Ain t the First', duration: '2:36' },
          { title: 'Bad Obsession', duration: '5:58' },
          { title: 'Back Off Bitch', duration: '5:03' },
          { title: 'Double Talkin Jive', duration: '3:23' },
          { title: 'Bad Apples', duration: '4:28' },
        ]
      },

       {
        title: 'Impera',
        artist: 'Ghost bc',
        image: require('./images/albumimpera.jpg'),
        songs: [
          { title: 'Spillways', duration: '3:16' },
          { title: 'Imperium', duration: '1:40' },
           { title: 'Kaisarion', duration: '5:02' },
            { title: 'Call Me Little Sunshine', duration: '4:44' },
             { title: 'Hunters Moon', duration: '3:16' },
              { title: 'Watcher in the Sky', duration: '5:46' },
               { title: 'Dominion', duration: '1:22' },
               { title: 'Twenties', duration: '3:46' },
               { title: 'Darkness at the Heart of My Love', duration: '4:56' },
               { title: 'Griftwood', duration: '5:16' },
        ]
      },

       {
        title: 'Meliora',
        artist: 'Ghost bc',
        image: require('./images/albummeliora.jpg'),
        songs: [
          { title: 'Spirit', duration: '5:15' },
          { title: 'From the Pinnacle to the Pit', duration: '4:02' },
          { title: 'Cirice', duration: '6:02' },
          { title: 'Spöksonat', duration: '0:56' },
          { title: 'He Is', duration: '4:13' },
          { title: 'Mummy Dust', duration: '4:07' },
          { title: 'Majesty', duration: '5:24' },
          { title: 'Devil Church', duration: '1:06' },
          { title: 'Absolution', duration: '4:50' },
          { title: 'Deus in Absentia', duration: '5:37' },
        ]
      },

       {
        title: 'Reise,Reise',
        artist: 'Rammstein',
        image: require('./images/albumriserise.jpg'),
        songs: [
          { title: 'Reise, Reise', duration: '4:11' },
          { title: 'Mein Teil ', duration: '5:32' },
          { title: 'Dalai Lama', duration: '5:38' },
          { title: 'Keine Lust ', duration: '3:42' },
          { title: 'Los', duration: '4:25' },
          { title: 'Amerika ', duration: '3:46' },
          { title: 'Moskau', duration: '4:16' },
          { title: 'Morgenstern', duration: '3:59' },
          { title: 'Stein um Stein', duration: '3:56' },
          { title: 'Ohne dich ', duration: '4:32' },
        ]
      },

       {
        title: 'Gaia II',
        artist: 'Mago de Oz',
        image: require('./images/albumgaia.jpg'),
        songs: [
          { title: 'La cantata del diablo', duration: '21:11' },
          { title: 'Volaverunt opus 666', duration: '4:25' },
           { title: 'La voz dormida', duration: '9:58' },
            { title: 'Hazme un sitio entre tu piel', duration: '4:54' },
             { title: 'El poema de la lluvia triste', duration: '7:52' },
              { title: 'El callejón del infierno', duration: '5:57' },
               { title: 'El paseo de los tristes', duration: '5:20' },
                { title: 'Desde mi cielo', duration: '6:20' },
                 { title: 'En nombre de Dios', duration: '7:04' },
                  { title: 'El príncipe de la dulce pena', duration: '1:35' },
        ]
      },

       {
        title: 'Bandera Negra',
        artist: 'Mago de Oz',
        image: require('./images/albumnegra.jpg'),
        songs: [
          { title: 'La isla de las siete calaveras', duration: '2:04' },
          { title: 'Al abordaje', duration: '8:23' },
           { title: 'Resacosix en pandemia', duration: '4:13' },
            { title: 'No te fallaré', duration: '4:12' },
             { title: 'La dama del mar', duration: '4:35' },
              { title: 'El aplauso herido', duration: '4:52' },
               { title: 'Guerra y paz', duration: '4:45' },
                { title: 'El cervezo (El árbol de la birra)', duration: '4:40' },
                 { title: 'Abrazos que curan', duration: '3:00' },
                  { title: 'Quiero que apagues mi luz', duration: '4:10' },
        ]
      },


    ],
  },





  
  {
    name: 'Pop',
    albums: [
      {
         title: 'Thriller',
        artist: 'Michael Jackson',
        image: require('./images/albumtriller.png'),
        songs: [
          { title: 'Wanna Be Startin Somethin', duration: '6:03' },
          { title: 'Baby Be Mine', duration: '4:20' },
          { title: 'The Girl Is Mine', duration: '3:42' },
          { title: 'Thriller', duration: '5:57' },
          { title: 'Beat It', duration: '4:19' },
          { title: 'Billie Jean', duration: '4:54' },
          { title: 'Human Nature', duration: '4:05' },
          { title: 'P.Y.T. (Pretty Young Thing)', duration: '3:58' },
          { title: 'The Lady in My Life', duration: '4:59' },
        ]
      },
      {
        title: 'Bad',
        artist: 'Michael Jackson',
        image: require('./images/albumbad.png'),
        songs: [
          { title: 'Bad', duration: '4:08' },
          { title: 'The Way You Make Me Feel', duration: '4:59' },
          { title: 'Speed Demon', duration: '4:01' },
          { title: 'Liberian Girl', duration: '3:53' },
          { title: 'Just Good Friends', duration: '4:07' },
          { title: 'Another Part of Me', duration: '3:54' },
          { title: 'Man in the Mirror', duration: '5:19' },
          { title: 'I Just Cant Stop Loving You', duration: '4:54' },
          { title: 'Dirty Diana', duration: '4:41' },
          { title: 'Smooth Crimina', duration: '4:17' },
        ]
      },

       {
        title: 'News of the World',
        artist: ' Queen',
        image: require('./images/albumnewworld.png'),
        songs: [
          { title: '"We Will Rock You', duration: '2:01' },
          { title: 'We Are the Champions', duration: '2:59' },
          { title: 'Sheer Heart Attack', duration: '3:26' },
          { title: 'All Dead, All Dead', duration: '3:10' },
        { title: 'Spread Your Wings', duration: '4:34' },
        { title: 'Fight from the Inside', duration: '3:03' },
        { title: 'Get Down, Make Love', duration: '3:51' },
        { title: 'Sleeping on the Sidewalk', duration: '3:06' },
        { title: 'Who Needs You', duration: '3:05' },
        { title: 'Its Late', duration: '6:26' },
        ]
      },

       {
        title: 'Enema of the State',
        artist: 'Blind 182',
        image: require('./images/albumblind.jpg'),
        songs: [
          { title: 'Dumpweed', duration: '2:23' },
          { title: 'Dont Leave Me', duration: '2:23' },
          { title: 'Aliens Exist', duration: '3:13' },
          { title: 'Going Away to College', duration: '2:59' },
          { title: 'Whats My Age Again?', duration: '2:28' },
          { title: 'Dysentery Gary', duration: '2:45' },
          { title: '"Adams Song"', duration: '4:09' },
          { title: 'All the Small Things', duration: '2:48' },
          { title: 'The Party Song', duration: '2:19' },
          { title: 'Mutt', duration: '3:23' },
        ]
      },

       {
        title: 'Abbey Road',
        artist: 'The Beatles',
        image: require('./images/albumabbey.jpg'),
        songs: [
          { title: 'Come Together', duration: '4:19' },
          { title: 'Something', duration: '3:02' },
          { title: 'Maxwells Silver Hammer', duration: '3:27' },
          { title: '"Oh! Darling', duration: '3:27' },
          { title: 'Octopuss Garden', duration: '2:51' },
          { title: '"I Want You (Shes So Heavy)"', duration: '7:27' },
          { title: 'Here Comes the Sun', duration: '3:05' },
          { title: 'Because', duration: '2:45' },
          { title: 'You Never Give Me Your Money', duration: '4:05' },
          { title: 'Sun King', duration: '2:26' },
        ]
      },

       {
        title: '1989 (álbum)',
        artist: 'Taylor Swift',
        image: require('./images/albumtaylor.png'),
        songs: [
          { title: 'Welcome to New York', duration: '3:32' },
          { title: 'Blank Space', duration: '3:51' },
           { title: 'Style', duration: '3:51' },
            { title: 'Out of the Woods', duration: '3:55' },
             { title: 'All You Had to Do Was Stay', duration: '3:13' },
              { title: 'Shake It Off', duration: '3:39' },
               { title: 'I Wish You Would', duration: '3:27' },
                { title: 'Bad Blood', duration: '3:31' },
                 { title: 'Wildest Dreams', duration: '3:40' },
                  { title: 'How You Get the Girl', duration: '3:07' },
        ]
      },

       {
        title: 'One of the Boys',
        artist: 'Katy Perry',
        image: require('./images/albumperry.png'),
        songs: [
          { title: 'One of the Boys', duration: '4:07' },
          { title: 'I Kissed a Girl', duration: '3:00' },
          { title: 'Waking Up in Vegas', duration: '3:20' },
          { title: 'Thinking of You', duration: '4:06' },
          { title: 'Mannequin', duration: '3:17' },
          { title: '«Ur So Gay', duration: '3:37' },
          { title: 'If You Can Afford Me', duration: '3:19' },
          { title: 'Lost', duration: '4:15' },
          { title: 'Self Inflicted', duration: '3:25' },
          { title: 'Im Still Breathing', duration: '3:48' },
        ]
      },

       {
        title: 'Oops!... I Did It Again',
        artist: ' Britney Spears',
        image: require('./images/albumspears.png'),
        songs: [
          { title: 'Oops!... I Did It Again', duration: '3:51' },
          { title: 'Stronger', duration: '3:23' },
          { title: 'Dont Go Knockin on My Door', duration: '3:43' },
          { title: '(I Cant Get No) Satisfaction', duration: '3:23' },
          { title: 'Dont Let Me Be the Last to Know', duration: '3:50' },
          { title: 'What U See (Is What U Get)', duration: '3:36' },
          { title: '"Lucky"', duration: '3:26' },
          { title: 'One Kiss from You', duration: '3:23' },
          { title: 'Where Are You Now', duration: '4:39' },
          { title: 'Cant Make You Love Me', duration: '3:17' },
        ]
      },

       {
        title: 'Shes So Unusual',
        artist: 'Cyndi Lauper',
        image: require('./images/albumlooper.png'),
        songs: [
          { title: 'Money Changes Everything', duration: '5:05' },
          { title: 'Girls Just Want to Have Fun', duration: '3:58' },
          { title: 'When You Were Mine', duration: '5:06' },
          { title: 'Time After Time', duration: '4:01' },
          { title: 'She Bop', duration: '3:49' },
          { title: 'All Through the Night', duration: '4:32' },
          { title: 'Witness', duration: '3:40' },
          { title: 'I ll Kiss You', duration: '4:12' },
          { title: 'Hes So Unusua', duration: '0:45' },
          { title: 'Yeah Yeah', duration: '3:18' },
        ]
      },

       {
        title: 'The Stranger',
        artist: ' Billy Joel',
        image: require('./images/albumstarnger.jpg'),
        songs: [
          { title: 'Movin Out (Anthonys Song)', duration: '3:30' },
          { title: 'The Stranger', duration: '5:08' },
          { title: 'Just the Way You Are', duration: '4:50' },
          { title: 'Scenes From An Italian Restauran', duration: '7:37' },
          { title: 'Vienna', duration: '3:34' },
          { title: 'Only the Good Die Young', duration: '3:55' },
          { title: 'Shes Always a Woman', duration: '3:21' },
          { title: 'Get It Right the First Time', duration: '3:57' },
          { title: 'Everybody Has a Dream/The Stranger (Reprise)', duration: '6:38' },
        ]
      },
    ],
  },

 {
    name: 'Latino',
    albums: [
      {
        title: 'Un verano sin ti',
        artist: 'Bad Bunny',
        image: require('./images/albumbadbuny.jpg'),
        songs: [
          { title: 'Moscow Mule', duration: '4:05' },
          { title: 'Después de la playa', duration: '3:50' },
          { title: 'Me porto bonito', duration: '2:58' },
          { title: 'Tití me preguntó', duration: '4:03' },
          { title: 'Un ratito', duration: '2:56' },
          { title: 'Yo no soy celoso', duration: '3:50' },
          { title: 'Tarot', duration: '3:57' },
          { title: 'Neverita', duration: '2:53' },
          { title: 'La corriente', duration: '3:18' },
          { title: 'Efecto', duration: '3:33' },
        ]
      },
      {
        title: 'Fórmula, vol. 3',
        artist: 'Romeo Santos',
        image: require('./images/albumromeo.jpg'),
        songs: [
          { title: 'Bebo', duration: '3:55' },
          { title: 'Ayúdame', duration: '3:44' },
          { title: 'Boomerang', duration: '4:07' },
          { title: 'Sexo con ropa', duration: '3:06' },
          { title: 'Ciudadana', duration: '3:33' },
          { title: 'Mar', duration: '3:23' },
          { title: 'Perro', duration: '3:40' },
          { title: 'Sin fin', duration: '3:54' },
          { title: 'Solo conmigo', duration: '4:14' },
          { title: 'Sus huellas', duration: '3:34' },
        ]
      },

      {
        title: 'F.A.M.E.',
        artist: 'Maluma',
        image: require('./images/albumfame.jpg'),
        songs: [
          { title: 'Corazón', duration: '3:03' },
          { title: 'El préstamo', duration: '3:39' },
          { title: 'Cuenta a saldo', duration: '3:17' },
          { title: 'Hangover', duration: '4:01' },
          { title: 'Mi declaración', duration: '3:45' },
          { title: 'How I Like It', duration: '2:51' },
          { title: 'Delincuente', duration: '3:26' },
          { title: 'Condena', duration: '3:29' },
          { title: 'Ojos que no ven', duration: '3:40' },
          { title: 'La ex', duration: '3:11' },
        ]
      },

      {
        title: 'Ahora(Album)',
        artist: 'Christian Nodal',
        image: require('./images/albumnodal.png'),
        songs: [
          { title: 'Que te olvide', duration: '3:22' },
          { title: 'No te contaron mal', duration: '2:36' },
           { title: 'Para olvidarme', duration: '2:48' },
            { title: 'El dolor con el licor', duration: '3:10' },
             { title: 'Juro por esta', duration: '3:36' },
              { title: 'Por orgullo', duration: '3:54' },
               { title: '¿Quién es usted?', duration: '3;06' },
                { title: 'Si te falta alguien', duration: '3:07' },
                 { title: 'Si usted fuera yo', duration: '3:07' },
                  { title: 'Esta noche', duration: '3:37' },
        ]
      },
      {
        title: 'Visualízate',
        artist: 'Gente de Zona',
        image: require('./images/albumzona.jpg'),
        songs: [
          { title: 'La Gozadera', duration: '3:23' },
          { title: 'Algo Contigo', duration: '3:30' },
          { title: 'Piensas (Dile la Verdad)', duration: '3:46' },
          { title: 'Por Ti', duration: '3:29' },
          { title: 'La Tentación', duration: '3:17' },
          { title: 'Que Tú Quieres', duration: '3:39' },
          { title: 'Más Whisky', duration: '3:29' },
          { title: 'Tú Me Quemas', duration: '4:28' },
          { title: 'Yo Quiero (Si Tu Te Enamoras)', duration: '3:27' },
          { title: 'Traidor', duration: '3:36' },
        ]
      },
      {
        title: 'Dharma',
        artist: 'Sebastián Yatra',
        image: require('./images/albumyatra.jpg'),
        songs: [
          { title: 'Básicamente', duration: '2:25' },
          { title: 'Dharma', duration: '3:16' },
          { title: 'Modo avión', duration: '2:49' },
          { title: 'Quererte bonito', duration: '4:30' },
          { title: 'Tacones rojos', duration: '3:08' },
          { title: 'Amor pasajero', duration: '2:32' },
          { title: 'Regresé', duration: '3:15' },
          { title: 'Si me la haces', duration: '3:08' },
          { title: 'Tarde', duration: '3:05' },
          { title: 'Melancólicos anónimos', duration: '3:19' },
        ]
      },
      {
        title: 'Mañana se Bonito',
        artist: 'Karol G',
        image: require('./images/albumkarol.jpg'),
        songs: [
          { title: 'Mientras me curo del cora', duration: '2:44' },
          { title: 'X si volvemos', duration: '3:20' },
          { title: 'Pero tú', duration: '3:03' },
          { title: 'Besties', duration: '2:42' },
          { title: 'Gucci los paños', duration: '3:06' },
          { title: 'Tus gafitas', duration: '3:17' },
          { title: 'Mercurio', duration: '2:40' },
          { title: 'Kármika', duration: '3:56' },
          { title: 'Provenza', duration: '3:27' },
          { title: 'Carolina', duration: '2:41' },
        ]
      },
      {
        title: 'Aguilera (álbum)',
        artist: ' Christina Aguilera',
        image: require('./images/albumaguilera.jpg'),
        songs: [
          { title: 'Ya Llegué', duration: '3:03' },
          { title: 'Pa Mis Muchachas', duration: '3:36' },
          { title: 'Somos nada', duration: '3:01' },
          { title: 'Santo', duration: '3:03' },
          { title: 'Como Yo', duration: '2:46' },
          { title: 'La Reina', duration: '3:48' },
          { title: 'Suéltame', duration: '2:53' },
          { title: 'Brujería', duration: '2:45' },
          { title: 'Traguito', duration: '3:11' },
          { title: 'Cuando Me Dé la Gana', duration: '3:26' },
        ]
      },
      {
        title: 'The Last',
        artist: 'Aventura',
        image: require('./images/albumaventura.jpg'),
        songs: [
          { title: 'Intro', duration: '1:24' },
          { title: 'Por un segundo', duration: '4:24' },
          { title: 'Yo quisiera amarla', duration: '5:06' },
          { title: 'El malo', duration: '3:58' },
          { title: 'Dile al amor', duration: '3:49' },
          { title: 'Su veneno', duration: '4:00' },
          { title: 'Tu jueguito', duration: '3:42' },
          { title: 'Spanish Fly', duration: '4:57' },
          { title: 'Peligro', duration: '4:38' },
          { title: 'La tormenta', duration: '4:35' },
        ]
      },
      {
        title: 'Romance (álbum de Luis Miguel)',
        artist: 'Luis Miguel',
        image: require('./images/albummiguel.jpg'),
        songs: [
          { title: 'No me platiques más', duration: '3:33' },
          { title: 'Inolvidable', duration: '4:17' },
          { title: 'La puerta', duration: '3:19' },
          { title: 'La barca', duration: '3:29' },
          { title: 'Te extraño', duration: '4:24' },
          { title: 'Usted', duration: '3:43' },
          { title: 'Contigo en la distancia', duration: '3:23' },
          { title: 'Mucho corazón', duration: '3:47' },
          { title: 'La mentira', duration: '3:48' },
          { title: 'Cuando vuelva a tu lado', duration: '3:49' },
        ]
      },
    ],
 }
];



const GenreScreen = () => {
  const [selectedAlbum, setSelectedAlbum] = useState(null);

  const handleAlbumPress = (album) => {
    setSelectedAlbum(album);
  };

  const handleBackPress = () => {
    setSelectedAlbum(null);
  };

  const renderAlbums = (albums) => {
    return albums.map((album, index) => (
      <TouchableOpacity
        key={index}
        onPress={() => handleAlbumPress(album)}
      >
        <View style={styles.albumContainer}>
          <Image source={album.image} style={styles.albumImage} />
          <Text style={styles.albumTitle}>{album.title}</Text>
          <Text style={styles.albumArtist}>{album.artist}</Text>
        </View>
      </TouchableOpacity>
    ));
  };

  const renderSongs = (songs) => {
    return songs.map((song, index) => (
      <View key={index} style={styles.songContainer}>
        <View style={styles.songInfo}>
          <Text style={styles.songTitle}>{song.title}</Text>
          <Text style={styles.songDuration}>{song.duration}</Text>
        </View>
        <TouchableOpacity onPress={() => alert(`Reproducir: ${song.title}`)}>
          <Text>Reproducir</Text>
        </TouchableOpacity>
      </View>
    ));
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.mainTitle}>Music UDB</Text>
      {selectedAlbum ? (
        <View>
          <Text style={styles.albumTitle}>{selectedAlbum.title}</Text>
          {renderSongs(selectedAlbum.songs)}
          <TouchableOpacity onPress={handleBackPress}>
            <Text>Volver</Text>
          </TouchableOpacity>
        </View>
      ) : (
        genres.map((genre, index) => (
          <View key={index} style={styles.genreContainer}>
            <Text style={styles.genreTitle}>{genre.name}</Text>
            <ScrollView horizontal>
              {renderAlbums(genre.albums)}
            </ScrollView>
          </View>
        ))
      )}
    </ScrollView>
  );
};

export default GenreScreen;

