

import React from 'react';
import { View, Text, ScrollView } from 'react-native';

const AlbumDetailScreen = ({ route }) => {
  const { album } = route.params;

  return (
    <ScrollView>
      {album.songs.map((song, index) => (
        <View key={index} style={{ padding: 10, borderBottomWidth: 1, borderBottomColor: '#ccc' }}>
          <Text style={{ fontSize: 18 }}>{song.title}</Text>
          <Text>{song.artist}</Text>
          <Text>{song.duration}</Text>
        </View>
      ))}
    </ScrollView>
  );
};

export default AlbumDetailScreen;
