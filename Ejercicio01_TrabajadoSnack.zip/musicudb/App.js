

import React, { useState } from 'react';
import { View } from 'react-native';
import GenreScreen from './src/GenreScreen';

const App = () => {
  return (
    <View style={{ flex: 1 }}>
      <GenreScreen />
    </View>
  );
};

export default App;
